/*
  Pham Hoang Hai Nam
  MSSV: 20215099
  Ghi chu.
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef struct node_s {
  char key[100];
  int count;
  struct node_s *left;
  struct node_s *right;
} node_t;
typedef node_t *tree_t;
void insertNode(char x[], tree_t *pRoot) {
  if (*pRoot == NULL) {
    /* Create a new node for key x */ 
    *pRoot = (node_t *)malloc(sizeof(node_t));
    strcpy((*pRoot)->key,x);
    (*pRoot)->count = 1;
    (*pRoot)->left = NULL;
    (*pRoot)->right = NULL;
  } else if (strcmp((*pRoot)->key,x) > 0)
    insertNode(x, &((*pRoot)->left));
  else if (strcmp((*pRoot)->key,x) < 0)
    insertNode(x, &((*pRoot)->right));
  else if (strcmp((*pRoot)->key,x) ==0)
    {  
      //insertNode(x, &(*pRoot));
      (*pRoot)->count++;
    }
}
char *XoaKyTu(char s[],char s1[])
{
    int len=strlen(s);
    int i;
    const char c[2] = " ";
    for(i=0;i<len;i++)
        {
            if(s[i]==s1[0])
                {
                    int j;
                    for(j=i;j<len;j++)
                        {
                            s[j]=s[j+1];
                        }
                    s[j+1] = '\0';
                    i--;
                }
        }
    return s;
}
char *Convert(char s[],unsigned char s1)
{
    for (int i = 0; s[i] != '\0'; i++)
    {
        if (s[i] == s1)
        {
          s[i] = 32;
        }
    }
    return s;
}
void DuyetTuCayVaoFile(tree_t tree, FILE *fpout){
    if (tree != NULL){
      DuyetTuCayVaoFile(tree->left,fpout);
      fprintf(fpout,"%s %d\n",tree->key,tree->count);
      DuyetTuCayVaoFile(tree->right,fpout);
    }
}
void inorderprint(tree_t tree){
    if (tree != NULL)
    {
      inorderprint(tree->left);
      printf("%s %d\n",tree->key,tree->count);
      inorderprint(tree->right);
    }    
}
void freeTree(tree_t tree) {
  if (tree != NULL) {
    freeTree(tree->left);
    freeTree(tree->right);
    free((void *)tree);
  }
}  
int main(int argc, char *argv[]){
	if (argc != 3){
		printf("Wrong number of arguments!\n");
		return 1;
	}
  tree_t p = NULL;
  FILE *fp; FILE *fpout;
  unsigned char space = 32;
  int c, d = 0;
  char *str = (char*)malloc(sizeof(char));
  if((fp = fopen(argv[1],"r")) == NULL)
    {
      printf("Error!! Unable to open the file.");
    }else 
      if((fpout = fopen(argv[2],"w")) == NULL)
    {
      printf("Error!! Unable to open the file.");
    }else{       
      do
      { 
        c = fscanf(fp,"%s",str);
        strupr(str);
        XoaKyTu(str,",");
        XoaKyTu(str,".");
        XoaKyTu(str,"@");
        XoaKyTu(str,"!");
        XoaKyTu(str,"#");
        XoaKyTu(str,"$");
        XoaKyTu(str,"%");
        XoaKyTu(str,"^");
        XoaKyTu(str,"&");
        XoaKyTu(str,"*");
        XoaKyTu(str,"(");
        XoaKyTu(str,")");
        XoaKyTu(str,"-");
        XoaKyTu(str,"_");
        XoaKyTu(str,"+");
        XoaKyTu(str,"=");
        XoaKyTu(str,"{");
        XoaKyTu(str,"}");
        XoaKyTu(str,"[");
        XoaKyTu(str,"]");
        XoaKyTu(str,"\\");
        XoaKyTu(str,"|");
        XoaKyTu(str,":");
        XoaKyTu(str,";");
        XoaKyTu(str,"\"");
        XoaKyTu(str,"'");
        XoaKyTu(str,"<");
        XoaKyTu(str,">");
        XoaKyTu(str,"?");
        XoaKyTu(str,"/");
        if (c != EOF)
        {        
          insertNode(str,&p);
        }
      } while (c != EOF);
      inorderprint(p);
      DuyetTuCayVaoFile(p,fpout);
  }
    fclose(fp);
    fclose(fpout);
    free(str);
    freeTree(p);
  return 0;
}